import { Component, OnInit } from '@angular/core';
import{FormGroup, FormControl, FormBuilder, Validators} from'@angular/forms';

import { Router } from '@angular/router';
import { UserRegistrationService } from 'src/app/services/user-registration.service';
import { UserRegistrationDetails } from 'src/app/model/user-registration';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user:string;
  pass:string;
  repass:string;
  mail:string;
  avilable:string="";
  validate : boolean=false;
  myFormGroup : FormGroup;
  constructor(public details : UserRegistrationService,public route : Router, formBuilder: FormBuilder) {
    console.log("in form bilder of reg");
    this.myFormGroup=formBuilder.group({
      "username":new FormControl(""),
      "password": new FormControl(""),
      "repassword":new FormControl(""),
      "email":new FormControl("")

    });

  }
  reg(uname:HTMLInputElement,pwd:HTMLInputElement,repwd:HTMLInputElement,email:HTMLInputElement){
    console.log("Registration method");
    let details=new UserRegistrationDetails(uname.value,pwd.value,repwd.value,email.value)
    
    if(pwd.value.length==0||uname.value.length==0||email.value.length==0){
      alert("please enter all the fields!!");
    }
    else if(pwd.value!=repwd.value ){
      alert("Passwords should be same");
    }
    else{
     this.user= this.myFormGroup.controls['username'].value;
    this.pass=this.myFormGroup.controls['password'].value;
    this.repass=this.myFormGroup.controls['repassword'].value;
    this.mail=this.myFormGroup.controls['email'].value;
    this.details.addNewUser(details).subscribe((response)=>console.log(response));
    this.route.navigate(['/login']);
   console.log("Username : "+this.user+"\n"+"Password : "+this.pass+"\n"+"Re-password : "+this.repass+"\n"+"Email : "+this.mail);
  }
}
validateUserName(uname:HTMLInputElement){
  if(uname.value=="First"){
    alert("UserName taken");
  }
  else if(uname.value.length==0){
    alert("please enter username first");
  }
  else{
    this.validate=true;
    this.avilable="Username Available"
  }
}

  ngOnInit() {
  }

}
