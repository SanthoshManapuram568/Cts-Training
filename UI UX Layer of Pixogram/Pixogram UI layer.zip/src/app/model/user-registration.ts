export class UserRegistrationDetails{
    username :string;
    password : string;
    rePassword : string;
    email : string;

    constructor(username:string, password : string,rePassword : string, email : string){
       this.username=username;
       this.password=password;
       this.rePassword=rePassword;
       this.email=email;

    }
}