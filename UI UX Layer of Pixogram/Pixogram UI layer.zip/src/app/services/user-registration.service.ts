import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegistrationDetails } from '../model/user-registration';
export const API_URL="http://localhost:3000/user-details";


@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {

  constructor(public http:HttpClient) { }
  addNewUser(details:UserRegistrationDetails){
    return this.http.post(API_URL,details);

   }
   getUserDetails(){
   return this.http.get("API_URL");
   }
}
