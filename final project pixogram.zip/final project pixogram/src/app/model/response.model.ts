export class Response{
    message : String;
    timestamp : number;
    userId : number;
    profilePic : string;
    firstName : string;
    lastName : string;
    email : string;
}