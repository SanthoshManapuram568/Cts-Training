export class NewsFeedModel{
    userId : number;
    feed : string;
    createdOn : string;
}