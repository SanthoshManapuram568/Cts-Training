import { Media } from './media.model';

export class MediaListModel{
    filelist : Array<Media>;
}