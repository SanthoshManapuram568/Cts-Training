export class UserName
{
    userName:string;
    
}