package com.pixogram.actionservice.response;

import com.pixogram.actionservice.model.CountOfActionsModel;

public class ActionsCountResponse {
	
	public CountOfActionsModel actiondata;
}
