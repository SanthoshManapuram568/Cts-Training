
package com.pixogram.actionservice.model;

import java.util.List;

import com.pixogram.actionservice.entity.Action;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActionListModel {
	
	List<Action> actions;
}
