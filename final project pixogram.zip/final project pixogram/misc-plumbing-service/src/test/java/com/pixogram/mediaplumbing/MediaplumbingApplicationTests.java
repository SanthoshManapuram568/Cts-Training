package com.pixogram.mediaplumbing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaplumbingApplicationTests {

	@Test
	void contextLoads() {
	}

}
